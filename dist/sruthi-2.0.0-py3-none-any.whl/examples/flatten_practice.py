import json
from flatten_dict import flatten
from pprint import pprint

with open("record.json", "rb") as f:
    record = json.load(f)

pprint(record)


def leaf_reducer(k1, k2):
    # only use key of leaf element
    return k2

flattened_data = flatten(record, reducer='dot')

print(flattened_data == record)
pprint(flattened_data)