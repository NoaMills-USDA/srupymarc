import argparse
import requests
import json
import xmltodict
import tomli
import io
import pymarc
from lxml import etree
import re

""" 
    A simple program to request records from the ExLibris Alma SRU API
    and convert them into pymarc objects.
    Adapted from: https://github.com/USDA-REE-ARS/nal-library-systems-support/wiki/Using-the-ExLibris-Alma-SRU-API

    usage: alma_sru.py [-h] -o OPERATION [-q QUERY]
"""

# initialize argument parser
argParser = argparse.ArgumentParser()

# Adding required argument operation
argParser.add_argument('-o', '--operation', type=str,
                       help="SRU Operation (ex. explain, searchRetrieve)",
                       required=True)

# Adding optional argument query
argParser.add_argument('-q', '--query', type = str,
                       help = "SRU query#")

argParser.print_help()

# Read arguments from command line
args = argParser.parse_args()

if (args.operation == "searchRetrieve"):
    if(not args.query):
        print("missing conditionally required parameter --query")
        quit()

if args.operation:
    print("\nInvoking ExLibris Alma SRU API Operation: % s" % args.operation)
if args.operation == "searchRetrieve":
    print("Using query: % s " % args.query)

with open("alma_sru_config.toml", mode="rb") as fp:
    config = tomli.load(fp)
    url = config[args.operation]['url_minimal']
    params = dict(operation=args.operation, version='1.2')
    if(args.query):
        query = config[args.operation][args.query]
        recordSchema = config[args.operation]["record_schema"]
        maxRecords = config[args.operation]["max_records"]
        params["query"] = query
        #params["recordSchema"] = recordSchema
        params["maxRecords"] = maxRecords

print("URL: ", url)
print("Params: ", params)
xmlResponse = requests.get(url, params=params)
print("Constructed url: ", xmlResponse.url)
xmlContent = xmlResponse.content
root = etree.fromstring(xmlContent)
print(root.text)
if args.operation == "explain":
    data_dict = xmltodict.parse(xmlContent)
    jsonContent = json.dumps(data_dict, indent=4)
    print(jsonContent)
else:
    pymarc_records = []
    records = root.find('{*}records')
    i = 1
    for record in records:
        record_xml = record.find("{*}recordData/{*}record")
        marcxmlFile = io.BytesIO(etree.tostring(record_xml))
        pymarc_record = pymarc.marcxml.parse_xml_to_array(marcxmlFile)[0]
        print(f"Record {i} author: {pymarc_record.author}")
        pymarc_records.append(pymarc_record)
        i += 1
    print(f"Total number of pymarc records: {len(pymarc_records)}")

print("Done")